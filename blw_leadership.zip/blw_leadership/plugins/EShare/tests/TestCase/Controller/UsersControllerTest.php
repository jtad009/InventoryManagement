<?php
namespace Eshare\Test\TestCase\Controller;

use Cake\TestSuite\IntegrationTestCase;
use Eshare\Controller\UsersController;

/**
 * Eshare\Controller\UsersController Test Case
 */
class UsersControllerTest extends IntegrationTestCase
{

    /**
     * Test initial setup
     *
     * @return void
     */
    public function testInitialization()
    {
        $this->markTestIncomplete('Not implemented yet.');
    }
}
