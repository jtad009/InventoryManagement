<?php
namespace Eshare\Test\TestCase\Mailer;

use Cake\TestSuite\TestCase;
use Eshare\Mailer\DispatcherMailer;

/**
 * Eshare\Mailer\DispatcherMailer Test Case
 */
class DispatcherMailerTest extends TestCase
{

    /**
     * Test subject
     *
     * @var \Eshare\Mailer\DispatcherMailer
     */
    public $Dispatcher;

    /**
     * Test initial setup
     *
     * @return void
     */
    public function testInitialization()
    {
        $this->markTestIncomplete('Not implemented yet.');
    }
}
