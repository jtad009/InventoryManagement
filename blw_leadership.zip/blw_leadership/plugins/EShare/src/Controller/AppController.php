<?php

namespace EShare\Controller;

use App\Controller\AppController as BaseController;

class AppController extends BaseController
{
  public function beforeFilter(\Cake\Event\Event $event) {
      $this->viewBuilder()->layout('EShare.index');
      return parent::beforeFilter($event);
  }

    public function initialize() {
        $this->loadComponent('Auth', [
            'authenticate'=>[
                'Form'=>[
                    'passwordHasher' => [
                    'className' => 'Legacy'
                                    ],
                    'fields'=>[
                        'username'=>'email',
                        'password'=>'password'
                    ]
                ]
            ],
            'loginAction'=>[
                'controller'=>'users',
                'action'=>'login'
            ],
            'unauthorizedRedirect' => $this->referer(),
            'scope'=>['users.app'=>'email']
        ]);
        $this->loadComponent('EShare.Upload');
        return parent::initialize();

    }

}
