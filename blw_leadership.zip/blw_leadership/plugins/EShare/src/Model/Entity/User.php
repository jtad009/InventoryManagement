<?php
namespace Eshare\Model\Entity;

use Cake\ORM\Entity;

/**
 * User Entity
 *
 * @property int $id
 * @property string $title
 * @property string $firstname
 * @property string $surname
 * @property string $email
 * @property string $password
 * @property string $region
 * @property string $zone
 * @property string $church
 * @property string $country
 * @property \Cake\I18n\Time $birthdate
 * @property int $status
 * @property string $pin
 * @property int $admin
 * @property string $token
 * @property string $app
 * @property string reply_email
 * @property \App\Model\Entity\Comment[] $comments
 * @property \App\Model\Entity\Programgroup[] $programgroups
 * @property \App\Model\Entity\Program[] $programs
 */
class User extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        '*' => true,
        'id' => false
    ];

    /**
     * Fields that are excluded from JSON versions of the entity.
     *
     * @var array
     */
    protected $_hidden = [
        'password',
        'token'
    ];
}
