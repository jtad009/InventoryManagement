<?php
namespace EShare\Model\Behavior;

use Cake\ORM\Behavior;
use Cake\ORM\Query;
use Cake\ORM\Table;

/**
 * UserFind behavior
 */
class UserFindBehavior extends Behavior
{

    /**
     * Default configuration.
     *
     * @var array
     */
    protected $_defaultConfig = [];
    public function findUserEmail(Query $query, array $options){
        return $query->where(['email'=>$options['email'],'email_group_id'=>$options['group_id']]);
    }
}
