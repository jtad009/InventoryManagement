<?php
namespace EShare\Test\TestCase\Form;

use Cake\TestSuite\TestCase;
use EShare\Form\ComposeForm;

/**
 * EShare\Form\ComposeForm Test Case
 */
class ComposeFormTest extends TestCase
{

    /**
     * Test subject
     *
     * @var \EShare\Form\ComposeForm
     */
    public $Compose;

    /**
     * setUp method
     *
     * @return void
     */
    public function setUp()
    {
        parent::setUp();
        $this->Compose = new ComposeForm();
    }

    /**
     * tearDown method
     *
     * @return void
     */
    public function tearDown()
    {
        unset($this->Compose);

        parent::tearDown();
    }

    /**
     * Test initial setup
     *
     * @return void
     */
    public function testInitialization()
    {
        $this->markTestIncomplete('Not implemented yet.');
    }
}
