<?php
use Cake\Routing\RouteBuilder;
use Cake\Routing\Router;
use Cake\Routing\Route\DashedRoute;

Router::plugin(
    'EShare',
    ['path' => '/e-share/'],
    function (RouteBuilder $routes) {
      $routes->scope('/', function ($routes) { // always go back to login or users page when route url is called
          $routes->connect('/', ['controller' => 'Users','action' => 'compose']);
      });
      $routes->scope('/read-mail/', function ($routes) { // always go back to login or users page when route url is called
          $routes->connect('/read-mail/:arg1', ['controller' => 'Users','action' => 'index'],['pass'=>['arg1']]);
      });
        $routes->fallbacks(DashedRoute::class);
    }


);
