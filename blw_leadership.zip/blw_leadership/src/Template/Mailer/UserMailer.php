<?php

namespace App\Mailer;

use Cake\Mailer\Mailer;

class UserMailer extends Mailer{
    public function welcome($user){
        //$this->
                 $this->to($user->email)
                 
                ->subject(sprintf('Welcome %s', $user->name))
                ->template('default')
               ;
        echo $user->email;
    }
    public function resetPassword($user){
        $this
            ->to($user->email)
            ->subject('Reset password')
            ->set(['token' => $user->token]);
    }
}
