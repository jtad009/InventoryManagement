<?php
namespace Eshare\Test\TestCase\Controller;

use Cake\TestSuite\IntegrationTestCase;
use Eshare\Controller\EmailHistoriesController;

/**
 * Eshare\Controller\EmailHistoriesController Test Case
 */
class EmailHistoriesControllerTest extends IntegrationTestCase
{

    /**
     * Test initial setup
     *
     * @return void
     */
    public function testInitialization()
    {
        $this->markTestIncomplete('Not implemented yet.');
    }
}
