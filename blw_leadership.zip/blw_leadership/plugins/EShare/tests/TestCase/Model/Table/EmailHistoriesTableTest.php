<?php
namespace Eshare\Test\TestCase\Model\Table;

use Cake\ORM\TableRegistry;
use Cake\TestSuite\TestCase;
use Eshare\Model\Table\EmailHistoriesTable;

/**
 * Eshare\Model\Table\EmailHistoriesTable Test Case
 */
class EmailHistoriesTableTest extends TestCase
{

    /**
     * Test subject
     *
     * @var \Eshare\Model\Table\EmailHistoriesTable
     */
    public $EmailHistories;

    /**
     * Fixtures
     *
     * @var array
     */
    public $fixtures = [
        'plugin.eshare.email_histories',
        'plugin.eshare.users'
    ];

    /**
     * setUp method
     *
     * @return void
     */
    public function setUp()
    {
        parent::setUp();
        $config = TableRegistry::exists('EmailHistories') ? [] : ['className' => 'Eshare\Model\Table\EmailHistoriesTable'];
        $this->EmailHistories = TableRegistry::get('EmailHistories', $config);
    }

    /**
     * tearDown method
     *
     * @return void
     */
    public function tearDown()
    {
        unset($this->EmailHistories);

        parent::tearDown();
    }

    /**
     * Test initialize method
     *
     * @return void
     */
    public function testInitialize()
    {
        $this->markTestIncomplete('Not implemented yet.');
    }

    /**
     * Test validationDefault method
     *
     * @return void
     */
    public function testValidationDefault()
    {
        $this->markTestIncomplete('Not implemented yet.');
    }

    /**
     * Test buildRules method
     *
     * @return void
     */
    public function testBuildRules()
    {
        $this->markTestIncomplete('Not implemented yet.');
    }
}
