<?php
namespace Eshare\Model\Entity;

use Cake\ORM\Entity;
use PhpParser\Node\Scalar\String_;

/**
 * GroupMember Entity
 *
 * @property int $id
 * @property int $email_group_id
 * @property int $first_name
 * @property string $last_name
 * @property int $email
 *
 * @property \Eshare\Model\Entity\EmailGroup $email_group
 */
class GroupMember extends Entity
{
    public function _getFullname(){
        return $this->first_name.' '.$this->last_name;
    }
}
