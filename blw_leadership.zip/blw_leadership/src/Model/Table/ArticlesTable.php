<?php
namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * Articles Model
 *
 * @property \Cake\ORM\Association\BelongsTo $Programs
 * @property \Cake\ORM\Association\HasMany $Comments
 *
 * @method \App\Model\Entity\Article get($primaryKey, $options = [])
 * @method \App\Model\Entity\Article newEntity($data = null, array $options = [])
 * @method \App\Model\Entity\Article[] newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\Article|bool save(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\Article patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method \App\Model\Entity\Article[] patchEntities($entities, array $data, array $options = [])
 * @method \App\Model\Entity\Article findOrCreate($search, callable $callback = null)
 */
class ArticlesTable extends Table
{

    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config)
    {
        parent::initialize($config);

        $this->table('articles');
        $this->displayField('id');
        $this->primaryKey('id');
        
        $this->belongsTo('Programs', [
            'foreignKey' => 'program_id',
            'joinType' => 'INNER'
        ]);
        $this->hasMany('Comments', [
            'foreignKey' => 'article_id'
        ]);
        $this->addBehavior('Timestamp');
        $this->addBehavior('CatergoryUserFind');
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator)
    {
        $validator
            ->integer('id')
            ->allowEmpty('id', 'create');

        $validator
            ->requirePresence('article_title', 'create')
            ->notEmpty('article_title');

        $validator
            ->requirePresence('article_content', 'create')
            ->notEmpty('article_content');

//        $validator
//            ->date('post_date')
//            ->requirePresence('post_date', 'create')
//            ->notEmpty('post_date');

//        $validator
//            ->integer('comment_count')
//            ->requirePresence('comment_count', 'create')
//            ->notEmpty('comment_count');

        $validator
            ->requirePresence('attachment_link', 'create')
            ->allowEmpty('attachment_link','update')
                ->notEmpty('attachment_link', "Field cannot be empty", 'create');

        $validator
            //->integer('like_count')
            ->requirePresence('video_link', 'create')
            ->allowEmpty('video_link');

        $validator
            ->requirePresence('published', 'create')
            ->notEmpty('published');

        $validator
            ->requirePresence('attachement_type', 'create')
            ->notEmpty('attachement_type');
//        $validator->
        return $validator;
    }
   
    /**
     * Returns a rules checker object that will be used for validating
     * application integrity.
     *
     * @param \Cake\ORM\RulesChecker $rules The rules object to be modified.
     * @return \Cake\ORM\RulesChecker
     */
    public function buildRules(RulesChecker $rules)
    {
        $rules->add($rules->existsIn(['program_id'], 'Programs'));

        return $rules;
    }
}
