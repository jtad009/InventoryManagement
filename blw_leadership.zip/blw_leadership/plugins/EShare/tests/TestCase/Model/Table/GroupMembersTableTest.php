<?php
namespace Eshare\Test\TestCase\Model\Table;

use Cake\ORM\TableRegistry;
use Cake\TestSuite\TestCase;
use Eshare\Model\Table\GroupMembersTable;

/**
 * Eshare\Model\Table\GroupMembersTable Test Case
 */
class GroupMembersTableTest extends TestCase
{

    /**
     * Test subject
     *
     * @var \Eshare\Model\Table\GroupMembersTable
     */
    public $GroupMembers;

    /**
     * Fixtures
     *
     * @var array
     */
    public $fixtures = [
        'plugin.eshare.group_members',
        'plugin.eshare.email_groups'
    ];

    /**
     * setUp method
     *
     * @return void
     */
    public function setUp()
    {
        parent::setUp();
        $config = TableRegistry::exists('GroupMembers') ? [] : ['className' => 'Eshare\Model\Table\GroupMembersTable'];
        $this->GroupMembers = TableRegistry::get('GroupMembers', $config);
    }

    /**
     * tearDown method
     *
     * @return void
     */
    public function tearDown()
    {
        unset($this->GroupMembers);

        parent::tearDown();
    }

    /**
     * Test initialize method
     *
     * @return void
     */
    public function testInitialize()
    {
        $this->markTestIncomplete('Not implemented yet.');
    }

    /**
     * Test validationDefault method
     *
     * @return void
     */
    public function testValidationDefault()
    {
        $this->markTestIncomplete('Not implemented yet.');
    }

    /**
     * Test buildRules method
     *
     * @return void
     */
    public function testBuildRules()
    {
        $this->markTestIncomplete('Not implemented yet.');
    }
}
