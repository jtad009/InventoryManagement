<?php
namespace Eshare\Test\TestCase\Model\Table;

use Cake\ORM\TableRegistry;
use Cake\TestSuite\TestCase;
use Eshare\Model\Table\EmailGroupTable;

/**
 * Eshare\Model\Table\EmailGroupTable Test Case
 */
class EmailGroupTableTest extends TestCase
{

    /**
     * Test subject
     *
     * @var \Eshare\Model\Table\EmailGroupTable
     */
    public $EmailGroup;

    /**
     * Fixtures
     *
     * @var array
     */
    public $fixtures = [
        'plugin.eshare.email_group',
        'plugin.eshare.users',
        'plugin.eshare.group_members'
    ];

    /**
     * setUp method
     *
     * @return void
     */
    public function setUp()
    {
        parent::setUp();
        $config = TableRegistry::exists('EmailGroup') ? [] : ['className' => 'Eshare\Model\Table\EmailGroupTable'];
        $this->EmailGroup = TableRegistry::get('EmailGroup', $config);
    }

    /**
     * tearDown method
     *
     * @return void
     */
    public function tearDown()
    {
        unset($this->EmailGroup);

        parent::tearDown();
    }

    /**
     * Test initialize method
     *
     * @return void
     */
    public function testInitialize()
    {
        $this->markTestIncomplete('Not implemented yet.');
    }

    /**
     * Test validationDefault method
     *
     * @return void
     */
    public function testValidationDefault()
    {
        $this->markTestIncomplete('Not implemented yet.');
    }

    /**
     * Test buildRules method
     *
     * @return void
     */
    public function testBuildRules()
    {
        $this->markTestIncomplete('Not implemented yet.');
    }
}
