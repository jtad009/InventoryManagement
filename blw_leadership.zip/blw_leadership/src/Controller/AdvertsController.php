<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * Adverts Controller
 *
 * @property \App\Model\Table\AdvertsTable $Adverts
 */
class AdvertsController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Network\Response|null
     */
    public function index()
    {
        $adverts = $this->paginate($this->Adverts);

        $this->set(compact('adverts'));
        $this->set('_serialize', ['adverts']);
    }

    /**
     * View method
     *
     * @param string|null $id Advert id.
     * @return \Cake\Network\Response|null
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $advert = $this->Adverts->get($id, [
            'contain' => []
        ]);

        $this->set('advert', $advert);
        $this->set('_serialize', ['advert']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $advert = $this->Adverts->newEntity();
        if ($this->request->is('post')) {
            $advert = $this->Adverts->patchEntity($advert, $this->request->data);
            $advert->url = $this->Upload->send($this->request->data['url']);
            //$advert->date = time();
            if ($this->Adverts->save($advert)) {
                $this->Flash->success(__('The advert has been saved.'));

                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The advert could not be saved. Please, try again.'));
            }
        }
        $this->set(compact('advert'));
        $this->set('_serialize', ['advert']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Advert id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $advert = $this->Adverts->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $advert = $this->Adverts->patchEntity($advert, $this->request->data);
            if ($this->Adverts->save($advert)) {
                $this->Flash->success(__('The advert has been saved.'));

                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The advert could not be saved. Please, try again.'));
            }
        }
        $this->set(compact('advert'));
        $this->set('_serialize', ['advert']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Advert id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $advert = $this->Adverts->get($id);
        if ($this->Adverts->delete($advert)) {
            $this->Flash->success(__('The advert has been deleted.'));
        } else {
            $this->Flash->error(__('The advert could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }
}
