<?php
namespace Eshare\Test\TestCase\Controller;

use Cake\TestSuite\IntegrationTestCase;
use Eshare\Controller\GroupMembersController;

/**
 * Eshare\Controller\GroupMembersController Test Case
 */
class GroupMembersControllerTest extends IntegrationTestCase
{

    /**
     * Test initial setup
     *
     * @return void
     */
    public function testInitialization()
    {
        $this->markTestIncomplete('Not implemented yet.');
    }
}
