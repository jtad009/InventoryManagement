<?php

namespace App\Controller\Component;

use Cake\Controller\Component;
use Cake\Controller\ComponentRegistry;

/**
 * FCM component
 */
class FCMComponent extends Component {

    /**
     * Default configuration.
     *
     * @var array
     */
    protected $_defaultConfig = [];
    
    /**
     * Build data to push ro users
     * @param type $to to topic {/topics/topic_title} or to particular user token or to every user
     * @param type $title title of the message to be sent (OPtional)
     * @param type $message body of message to send
     */
    public function buildPayload($to,$title,$message)
    {
        return  $fields = array(
            'to' => $to,
            'notification' => array(
                "body" => $message,
                "title" => $title,
                "icon" => "myicon"
            )
        );
    }
    /**
     * Send notification to a particular topic
     * @param type $data data array to send
     */
    public function pushToServer($data) {
        $url = 'https://fcm.googleapis.com/fcm/send';
       
        $fields = json_encode($data);
        
        $headers = array(
            'Authorization: key=' . "AAAAj8qc1ic:APA91bG5DLXfH9rdZgt-UoehGnF5qOKIUp9ifFtrwbT8VH75T0WdaL77OlrnnubH-hD-qBpEWJ_eJkUt5fcCuHAPwEQ_KQOP_xgNSvM2S0BMeK77XF-E8Dp7FBNNkII_3ACDIANBy12eWEYQyT6OqC2YxCfY1fUchg",
            'Content-Type: application/json'
        );

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $fields);

        $result = curl_exec($ch);
        curl_close($ch);
        return $result;
    }

    /**
     * Send User Tokens to server
     * this tokens are for specific users
     * @param array $token user personal tokens
     */
    public function pushToServerViaToken(array $token) {
        
    }

}
