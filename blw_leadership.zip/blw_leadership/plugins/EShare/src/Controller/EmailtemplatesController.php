<?php
namespace Eshare\Controller;

use Cake\Log\Log;
use Cake\Utility\Text;
use EShare\Controller\AppController;

/**
 * Emailtemplates Controller
 *
 * @property \Eshare\Model\Table\EmailtemplatesTable $Emailtemplates
 */
class EmailtemplatesController extends AppController
{
    public function beforeFilter(\Cake\Event\Event $event) {
        $this->viewBuilder()->layout('EShare.index');
        return parent::beforeFilter($event);
    }

    /**
     * Index method
     *
     * @return \Cake\Network\Response|null
     */
    public function index()
    {
        $templates = $this->Emailtemplates->find()->where(['user_id'=>$this->Auth->user()['id']] // get templates from this particular templated author
        );
        $emailtemplates = $this->paginate($templates,[]);

        $this->set(compact('emailtemplates'));
        $this->set('_serialize', ['emailtemplates',$this->Auth->user()]);
    }

    /**
     * View method
     *
     * @param string|null $id Emailtemplate id.
     * @return \Cake\Network\Response|null
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $emailtemplate = $this->Emailtemplates->get($id, [
            'contain' => []
        ]);

        $this->set('emailtemplate', $emailtemplate);
        $this->set('_serialize', ['emailtemplate']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $emailtemplate = $this->Emailtemplates->newEntity();
        if ($this->request->is('post')) {
            $emailtemplate = $this->Emailtemplates->patchEntity($emailtemplate, $this->request->data);
            $emailtemplate->user_id = $this->Auth->user('id');

            if ($this->Emailtemplates->save($emailtemplate)) {
                $this->Flash->success(__('The emailtemplate has been saved.'));

                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The emailtemplate could not be saved. Please, try again.'));
            }
        }
        $this->set(compact('emailtemplate'));
        $this->set('_serialize', ['emailtemplate']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Emailtemplate id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $emailtemplate = $this->Emailtemplates->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $emailtemplate = $this->Emailtemplates->patchEntity($emailtemplate, $this->request->data);
              $emailtemplate->user_id = $this->Auth->user('id');
            if ($this->Emailtemplates->save($emailtemplate)) {
                $this->Flash->success(__('The emailtemplate has been saved.'));

                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The emailtemplate could not be saved. Please, try again.'));
            }
        }
        $this->set(compact('emailtemplate'));
        $this->set('_serialize', ['emailtemplate']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Emailtemplate id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $emailtemplate = $this->Emailtemplates->get($id);
        if ($this->Emailtemplates->delete($emailtemplate)) {
            $this->Flash->success(__('The emailtemplate has been deleted.'));
        } else {
            $this->Flash->error(__('The emailtemplate could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }
}
