<?php
namespace Eshare\Mailer;

use Cake\Log\Log;
use Cake\Mailer\Mailer;
use Cake\Datasource\ConnectionManager;


/**
 * Dispatcher mailer.
 */
class DispatcherMailer extends Mailer
{
    /**
     * Changes made 4/1/17
     * Email is not send individually per person
     */

    /**
     * Mailer's name.
     *
     * @var string
     */
    static public $name = 'Dispatcher';
    public $designation;
    public $church;
    private $emailBody = "";
    private $emailSubject = "";
    private $emailFrom = "";
    private $to = [];
    private $owner_name = "";
    private $user_id = 0;
    private $replyTo = "";
    private $APP_NAME = "";
    private $attachment;
    public function push($data,$to,$message,$owner = "")
    {
        $this->APP_NAME = $data['app_title'];
        $this->emailFrom = $data['emailFrom'];
        $this->emailSubject = $data['subject'];
        $this->emailBody = $message.'<br/>'.$data['signature'];
        $this->user_id = $data['user'];
        $this->to = $to;
        $this->owner_name = $owner;
        $this->replyTo = empty($data['replyTo'])?"jtad009@gmail.com" : $data['replyTo'];
        $this->attachment = $data['attachment'];
        Log::write('info',$this->attachment);
        $this->sendEmail();

}
    /**
     * Take a log of mail sent
     */
    public function saveSent(){
      // $sentTable = new EmailHistories();
      // $sent = $sentTable
      $connection  = ConnectionManager::get('default');
      $connection->insert('email_histories',[
        'user_id'=>$this->user_id,
        'receiver' =>$this->to,
        'message' => $this->emailBody,
        'froms'=>$this->emailFrom,
        'status'=>'SENT',
        'subject' => $this->emailSubject,

      ]);
    }

    /**
     * Send email out of system
     */
    public function sendEmail(){


        $this->reset();
        $this->to($this->to,$this->owner_name)
            ->replyTo($this->replyTo)

            ->from($this->emailFrom,!empty($this->APP_NAME) ? $this->APP_NAME : APP_NAME)
            ->subject($this->emailSubject)
            ->viewVars(array('content' => $this->emailBody)) // set the message to send to the $content variable of the \email\html\default template
                ->attachments($this->attachment)
            ->template('default')
            ->emailFormat('html');
        Log::write('info',$this->attachment);
        $this->saveSent();


//        debug($to_details);


    }
}
