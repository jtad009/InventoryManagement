<?php

namespace App\Controller;

use App\Controller\AppController;
use Cake\Mailer\MailerAwareTrait;
use Cake\Utility\Text;
use Cake\Log\Log;

//use App\View\Helper\FroalaHelper;
//use App\Mailer\WelcomerMailer;
/**
 * Users Controller
 *
 * @property \App\Model\Table\UsersTable $Users
 */
class UsersController extends AppController implements \Cake\Event\EventListenerInterface {

    use MailerAwareTrait;

    public function implementedEvents() {
        return array(
            'Model.Articles.created' => 'sendFCM',
            'Model.Emailtemplates.getUserDetails' => 'returnUserDetails'
        );
    }

    public function returnUserDetails(\Cake\Event\Event $event, $entity) {

        $user = $this->Users->find()->where(['email' => $event->data['email']['to']]);
        foreach ($user as $value) {
            $event = new \Cake\Event\Event('Model.Emailtemplates.sendWelcome', $this, ['email_data' => $event->data['email'], 'user' => $value->pin]);
        }
        
        $this->eventManager()->dispatch($event);
    }

    public function sendFCM(\Cake\Event\Event $event, $entity) {
        //if data is saved then send notification to the server t
//         $u = $this->Users->Programgroups->find('all')->where(['program_id'=>$event->data['article']['program_id']]);
        //For now work without associations until u learn them properly israel
        $programTable = \Cake\ORM\TableRegistry::get('Programs');
        $programs = $programTable->get($event->data['article']['program_id']);
        $programTopic = str_replace(' ', '', $programs->program);
        $data = $this->FCM->buildPayload('/topics/' . $programTopic, 'New Article: ' . $event->data['article']['article_title'], html_entity_decode(strip_tags($event->data['article']['article_content']))
        );
        $response = $this->FCM->pushToServer($data);
        Log::write(
                'info', 'A new post was published with program and pushed to fone: ' . $response);
    }

    public function beforeFilter(\Cake\Event\Event $event) {
        parent::beforeRender($event);
        $this->Auth->allow('add');
        // $this->helpers = array('Froala.Froala');
        $this->set('loggedIn', $this->Auth->user());
    }

    /**
     * Index method
     *
     * @return \Cake\Network\Response|null
     */
    public function index() {
        $this->dispatchLoginDetails(); // are the newly registered users if yes then dispatch their emails to them
        $users = $this->paginate($this->Users);

        $this->set(compact('users'));
        $this->set('_serialize', ['users']);
    }

    /**
     * View method
     *
     * @param string|null $id User id.
     * @return \Cake\Network\Response|null
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null) {
        $user = $this->Users->get($id, [
            'contain' => ['Comments', 'Programgroups', 'Programs']
        ]);

        $this->set('user', $user);
        $this->set('_serialize', ['user']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add() {
        $user = $this->Users->newEntity();
        if ($this->request->is('post')) {
            $user = $this->Users->patchEntity($user, $this->request->data);
            if ($this->Users->save($user)) {
                $this->Flash->success(__('The user has been saved.'));
                $this->getMailer('User')->send('welcome', [$user]);
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The user could not be saved. Please, try again.'));
            }
        }
        $this->set(compact('user'));
        $this->set('_serialize', ['user']);
    }

    /**
     * Edit method
     *
     * @param string|null $id User id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null) {
        $user = $this->Users->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $user = $this->Users->patchEntity($user, $this->request->data);
            if ($this->Users->save($user)) {
                $this->Flash->success(__('The user information has been updated.'));

                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The user could not be saved. Please, try again.'));
            }
        }
        $this->set(compact('user'));
        $this->set('_serialize', ['user']);
    }

    /**
     * Delete method
     *
     * @param string|null $id User id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null) {
        $this->request->allowMethod(['post', 'delete']);
        $user = $this->Users->get($id);
        if ($this->Users->delete($user)) {
            $this->Flash->success(__('The user has been deleted.'));
        } else {
            $this->Flash->error(__('The user could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }

    public function login() {
        $this->set('loggedIn', $this->Auth->user());
        // var_dump($this->Auth->user());
        if ($this->request->is("post")) { // if the request gotten is a post request
            $user = $this->Auth->identify(); // identify the user 
//            echo $user['admin'];
            //var_dump($user);
            if ($user['admin'] == 1) {
                
                $this->Auth->setUser($user);
                $this->set('loggedIn', $this->Auth->user());
                return $this->redirect($this->Auth->redirectUrl());
            }
            //User could not be identified
            $this->Flash->error("Your username or password is incorrect");
        }
    }

    public function logout() {
        $this->Flash->success("You are now logged out");
        return $this->redirect($this->Auth->logout());
    }

    public function welcomeEmail($user = null) {
        //TODO: A welcome email is sent to all participants: contents are [pin and welcome message ]
//        echo ;
//        require_once(ROOT .DS. "src" . DS  ."Template".DS. "Mailer" . DS . "UserMailer.php");
//        $mailer = new \App\Mailer\UserMailer();
//        $email = new Email();
//        $email->from('jtad009@gmail.com','Welcome Mail')
//        ->to('israeledet@yahoo.com','Me')
//                ->template('default','default')->send();
        //$mailer->send('welcome',[$this->Users->get($user)]);
        /*
         * Before email is sent the pin is generated and saved in the db then mailed to the user
         */
        $pin = substr(Text::Uuid(), 0, 7);
        $userTable = \Cake\ORM\TableRegistry::get('Users');
        $this_user = $userTable->get($user);
        $this_user->pin = $pin;
        $userTable->save($this_user);
        if (!$this->getMailer('Welcomer')->send('welcomeMail', [$this->Users->get($user), $pin])) {
            CakeLog::write('debug', $this->Email->smtpError); // 
        } else {
            return $this->redirect(['action' => 'index']);
        }
    }

    public function sendWelcomeEmail() {

        $users = $this->Users->find('all');
        if (!$this->getMailer('Welcomer')->send('welcomeMailToAll', [$users])) {
            CakeLog::write('debug', $this->Email->smtpError); // 
        } else {
            $this->redirect(['action' => 'index']);
        }
    }

    private function dispatchLoginDetails(){
        $dispatchTable = \Cake\ORM\TableRegistry::get('dispatch');
        $dispatchItems = $dispatchTable->find();
        
        $emailData = array();
        foreach ($dispatchItems as $row) {
            $emailData[$row->email] = $row->content;
            
        }
         if(count($emailData) > 0){
            $event = new \Cake\Event\Event('Model.Users.sendLoginDetails', $this, ['emails' => $emailData]);
            $this->eventManager()->dispatch($event);
            foreach ($dispatchItems as $row) {
                
                $dispatchTable->deleteAll(['email'=>$row->email]);
         }
           
         }
    }
}
