<?php
namespace App\Mailer;

use Cake\Mailer\Mailer;
use Cake\Utility\Text;
/**
 * Welcomer mailer.
 */
class WelcomerMailer extends Mailer
{

    /**
     * Mailer's name.
     *
     * @var string
     *3084085226*/
    static public $name = 'Welcomer';
    
    public function welcomeMail($user,$pin){
//       echo $pin;
                $this->to($user->email)
                
                ->subject(sprintf('Welcome %s', $user->name))
                ->viewVars(['username'=>$user->name,'pin'=>$pin])
                ->template('default');
    }
    public function welcomeMailToAll($users){
        $counter = 0;
        
        
        foreach($users as $user){
            
            $pin = substr(Text::Uuid(), 0,7);
            $userTable = \Cake\ORM\TableRegistry::get('Users');
            $this_user = $userTable->get($user->id);
            $this_user->pin = $pin;
            $userTable->save($this_user);
            
                    $this->to($user->email)
                    ->subject(sprintf('Welcome $s',$user->name))
                    ->viewVars(['username'=>$user->name,'pin'=>$pin])
                    -> template('welcomer');
        }
        
    }
    
}
