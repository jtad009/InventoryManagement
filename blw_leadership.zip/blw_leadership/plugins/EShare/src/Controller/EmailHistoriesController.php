<?php
namespace Eshare\Controller;

use Eshare\Controller\AppController;

/**
 * EmailHistories Controller
 *
 * @property \Eshare\Model\Table\EmailHistoriesTable $EmailHistories
 */
class EmailHistoriesController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Network\Response|null
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['Users']
        ];
        $emailHistories = $this->paginate($this->EmailHistories);

        $this->set(compact('emailHistories'));
        $this->set('_serialize', ['emailHistories']);
    }

    /**
     * View method
     *
     * @param string|null $id Email History id.
     * @return \Cake\Network\Response|null
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $emailHistory = $this->EmailHistories->get($id, [
            'contain' => ['Users']
        ]);

        $this->set('emailHistory', $emailHistory);
        $this->set('_serialize', ['emailHistory']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $emailHistory = $this->EmailHistories->newEntity();
        if ($this->request->is('post')) {
            $emailHistory = $this->EmailHistories->patchEntity($emailHistory, $this->request->data);
            if ($this->EmailHistories->save($emailHistory)) {
                $this->Flash->success(__('The email history has been saved.'));

                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The email history could not be saved. Please, try again.'));
            }
        }
        $users = $this->EmailHistories->Users->find('list', ['limit' => 200]);
        $this->set(compact('emailHistory', 'users'));
        $this->set('_serialize', ['emailHistory']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Email History id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $emailHistory = $this->EmailHistories->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $emailHistory = $this->EmailHistories->patchEntity($emailHistory, $this->request->data);
            if ($this->EmailHistories->save($emailHistory)) {
                $this->Flash->success(__('The email history has been saved.'));

                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The email history could not be saved. Please, try again.'));
            }
        }
        $users = $this->EmailHistories->Users->find('list', ['limit' => 200]);
        $this->set(compact('emailHistory', 'users'));
        $this->set('_serialize', ['emailHistory']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Email History id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $emailHistory = $this->EmailHistories->get($id);
        if ($this->EmailHistories->delete($emailHistory)) {
            $this->Flash->success(__('The email history has been deleted.'));
        } else {
            $this->Flash->error(__('The email history could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }
}
