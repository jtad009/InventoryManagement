<?php
namespace App\Test\TestCase\Mailer;

use App\Mailer\EmailsystemMailer;
use Cake\TestSuite\TestCase;

/**
 * App\Mailer\EmailsystemMailer Test Case
 */
class EmailsystemMailerTest extends TestCase
{

    /**
     * Test subject
     *
     * @var \App\Mailer\EmailsystemMailer
     */
    public $Emailsystem;

    /**
     * Test initial setup
     *
     * @return void
     */
    public function testInitialization()
    {
        $this->markTestIncomplete('Not implemented yet.');
    }
}
