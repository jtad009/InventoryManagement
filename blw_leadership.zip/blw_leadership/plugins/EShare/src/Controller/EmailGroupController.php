<?php
namespace Eshare\Controller;

use EShare\Controller\AppController;

/**
 * EmailGroup Controller
 *
 * @property \Eshare\Model\Table\EmailGroupTable $EmailGroup
 */
class EmailGroupController extends AppController implements \Cake\Event\EventListenerInterface
{
    use \Cake\Mailer\MailerAwareTrait;





    /**
     * Index method
     *
     * @return \Cake\Network\Response|null
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['Users'],
            


        ];
        $u = $this->EmailGroup->find()->where(['user_id'=>$this->Auth->user()['id']]);
        $emailGroup = $this->paginate($u,[ ]);

        $this->set(compact('emailGroup'));
        $this->set('_serialize', ['emailGroup']);
    }

    /**
     * View method
     *
     * @param string|null $id Email Group id.
     * @return \Cake\Network\Response|null
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $emailGroup = $this->EmailGroup->get($id, [
            'contain' => ['Users', 'GroupMembers']
        ]);

        $this->set('emailGroup', $emailGroup);
        $this->set('_serialize', ['emailGroup']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $emailGroup = $this->EmailGroup->newEntity();
        if ($this->request->is('post')) {
            $emailGroup = $this->EmailGroup->patchEntity($emailGroup, $this->request->data);
            $emailGroup->user_id = $this->Auth->user()['id']; // use the ID of the curently logged in user
            if ($this->EmailGroup->save($emailGroup)) {
                $this->Flash->success(__('The email group has been saved.'));

                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The email group could not be saved. Please, try again.'));
            }
        }
        $users = $this->EmailGroup->Users->find('list', ['limit' => 200,'app'=>'email']);
        $this->set(compact('emailGroup', 'users'));
        $this->set('_serialize', ['emailGroup']);
        \Cake\Log\Log::write("info","Hey tg");
    }

    /**
     * Edit method
     *
     * @param string|null $id Email Group id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $emailGroup = $this->EmailGroup->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $emailGroup = $this->EmailGroup->patchEntity($emailGroup, $this->request->data);
            $emailGroup->user_id = $this->Auth->user()['id']; // use the ID of the curently logged in user
            if ($this->EmailGroup->save($emailGroup)) {
                $this->Flash->success(__('The email group has been saved.'));

                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The email group could not be saved. Please, try again.'));
            }
        }
        $users = $this->EmailGroup->Users->find('list', ['limit' => 200]);
        $this->set(compact('emailGroup', 'users'));
        $this->set('_serialize', ['emailGroup']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Email Group id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $emailGroup = $this->EmailGroup->get($id);
        if ($this->EmailGroup->delete($emailGroup)) {
            $this->Flash->success(__('The email group has been deleted.'));
        } else {
            $this->Flash->error(__('The email group could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }

  

}
