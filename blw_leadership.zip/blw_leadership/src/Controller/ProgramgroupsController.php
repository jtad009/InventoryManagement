<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * Programgroups Controller
 *
 * @property \App\Model\Table\ProgramgroupsTable $Programgroups
 */
class ProgramgroupsController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Network\Response|null
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['Users', 'Programs']
        ];
        $programgroups = $this->paginate($this->Programgroups);

        $this->set(compact('programgroups'));
        $this->set('_serialize', ['programgroups']);
    }

    /**
     * View method
     *
     * @param string|null $id Programgroup id.
     * @return \Cake\Network\Response|null
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $programgroup = $this->Programgroups->get($id, [
            'contain' => ['Users', 'Programs']
        ]);

        $this->set('programgroup', $programgroup);
        $this->set('_serialize', ['programgroup']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $program_groups_table = \Cake\ORM\TableRegistry::get('Programgroups');
        //confirm if user is already registered for this group first
       
        $query = $program_groups_table->query();
        
        
            
        $programgroup = $this->Programgroups->newEntity();
        if ($this->request->is('post')) {
            $programgroup = $this->Programgroups->patchEntity($programgroup, $this->request->data);
           //search program_group table for data where user_id = int and program_id = int
           $isGroupMember = $this->Programgroups->find('all',[ 
               'conditions' => [
                                'user_id'=>$programgroup->user_id,'program_id'=>$programgroup->program_id
                                ]
                   ]);
          
           if($isGroupMember->count() > 0){ // if get result count > 0
              //then user exist in this program already redirect back to add page and show error
                $this->Flash->error(__('User already in this group.'));
                return $this->redirect(['action'=>'add']);
           }else{//insert the user into a group 
               $query->insert(['user_id', 'program_id'])
                ->values([
                'user_id' => $programgroup->user_id,
                'program_id' => $programgroup->program_id
                ]);
               if ($query->execute()) {
                    $this->Flash->success(__('The programgroup has been saved.'));

                    return $this->redirect(['action' => 'index']);
                } else {
                    //$this->log($programgroup)
                    $this->Flash->error(__('The programgroup could not be saved. Please, try again.'));
                }
           }
      }
     
        $users = $this->Programgroups->Users->find()->combine('id','firstname','surname');
        $programs = $this->Programgroups->Programs->find()->combine('id','program');
        $this->set(compact('programgroup', 'users', 'programs'));
        $this->set('_serialize', ['programgroup']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Programgroup id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $programgroup = $this->Programgroups->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $programgroup = $this->Programgroups->patchEntity($programgroup, $this->request->data);
            if ($this->Programgroups->save($programgroup)) {
                $this->Flash->success(__('The programgroup has been saved.'));

                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The programgroup could not be saved. Please, try again.'));
            }
        }
        $users = $this->Programgroups->Users->find()->combine('id','firstname');
        $programs = $this->Programgroups->Programs->find()->combine('id','program');
        $this->set(compact('programgroup', 'users', 'programs'));
        $this->set('_serialize', ['programgroup']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Programgroup id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $programgroup = $this->Programgroups->get($id);
        if ($this->Programgroups->delete($programgroup)) {
            $this->Flash->success(__('The programgroup has been deleted.'));
        } else {
            $this->Flash->error(__('The programgroup could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }
}
