<?php
$groupListener = new EShare\Controller\EmailGroupController();

use Cake\Event\EventManager;
EventManager::instance()->attach($groupListener);

