
<?php

//ini_set("sendmail_path", "C:\wamp\bin\sendmail.exe -t");
/*Gmail component setup in cakephp by Shaharia Azam (shaharia.azam@gmail.com)*/
class EmailConfig {
    public $gmail = array(
        'host' => 'ssl://smtp.gmail.com',
        'port' => 465,
        'username' => 'jtad009@gmail.com',
        'password' => 'sc3oo6by290@',
        'transport' => 'Smtp'
    );
}
?>
