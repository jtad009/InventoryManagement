<?php
namespace App\Model\Entity;

use Cake\Log\LogTrait;
use Cake\ORM\Entity;
use Cake\Auth\DefaultPasswordHasher;

/**
 * User Entity
 *
 * @property int $id
 * @property string $title
 * @property string $firstname
 * @property string $surname
 * @property string $email
 * @property string $password
 * @property string $region
 * @property string $zone
 * @property string $church
 * @property string $country
 * @property \Cake\I18n\Time $birthdate
 * @property int $status
 *
 * @property \App\Model\Entity\Comment[] $comments
 * @property \App\Model\Entity\Programgroup[] $programgroups
 * @property \App\Model\Entity\Program[] $program
 */
class User extends Entity
{
use LogTrait;
    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        '*' => true,
        'id' => false
    ];

    /**
     * Fields that are excluded from JSON versions of the entity.
     *
     * @var array
     */
    protected $_hidden = [
        'password'
    ];
    protected function _setPassword($password){
        $this->Log('User Changing password','debug');
        $hasher = new DefaultPasswordHasher();
        //$hasher->hash($password); shud i want to use cake php's hasher
        return md5($password);
    }
    protected function _getFullName() {
        return $this->_properties['firstname'].' '.$this->_properties['surname'];
    }
    protected function _getFullNameWithTitle() {
        return $this->title .' '. $this->firstname.' '. $this->surname;
    }
    
}
