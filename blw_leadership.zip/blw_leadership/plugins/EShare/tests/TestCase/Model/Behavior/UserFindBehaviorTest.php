<?php
namespace EShare\Test\TestCase\Model\Behavior;

use Cake\TestSuite\TestCase;
use EShare\Model\Behavior\UserFindBehavior;

/**
 * EShare\Model\Behavior\UserFindBehavior Test Case
 */
class UserFindBehaviorTest extends TestCase
{

    /**
     * Test subject
     *
     * @var \EShare\Model\Behavior\UserFindBehavior
     */
    public $UserFind;

    /**
     * setUp method
     *
     * @return void
     */
    public function setUp()
    {
        parent::setUp();
        $this->UserFind = new UserFindBehavior();
    }

    /**
     * tearDown method
     *
     * @return void
     */
    public function tearDown()
    {
        unset($this->UserFind);

        parent::tearDown();
    }

    /**
     * Test initial setup
     *
     * @return void
     */
    public function testInitialization()
    {
        $this->markTestIncomplete('Not implemented yet.');
    }
}
