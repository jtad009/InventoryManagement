
$(document).ready(function(){
	$('textarea.summernote').summernote({
		height: jQuery(this).attr('data-height') || 200,
		lang: 	jQuery(this).attr('data-lang') || 'en-US', // default: 'en-US'
		toolbar: [
			/*	[groupname, 	[button list]]	*/
			['style', 		['style']],
			['fontsize', 	['fontsize']],
			['style', 		['bold', 'italic', 'underline','strikethrough', 'clear']],
			['color', 		['color']],
			['para', 		['ul', 'ol', 'paragraph']],
			['table', 		['table']],
			['media', 		['link', 'picture', 'video']],
			['misc', 		['codeview', 'fullscreen', 'help']]
		]
	});

	$('#templates').change(function(){
         console.log($.parseHTML($(this).val()));
         var str = $.parseHTML($(this).val());
				 var currentMsg = $('.note-editable').html();
         $('.note-editable').html(str);
     });
})
