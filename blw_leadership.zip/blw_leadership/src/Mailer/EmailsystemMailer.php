<?php
namespace App\Mailer;

use Cake\Mailer\Mailer;
use Cake\Log\Log;

/**
 * Emailsystem mailer.
 */
class EmailsystemMailer extends Mailer
{

    /**
     * Mailer's name.
     *
     * @var string
     */
    static public $name = 'Emailsystem';
    public function push($to) {
       
        $this->to($to['to'])
               ->subject($to['subject'])
               ->viewVars(array('content' => $to['message'])) // set the message to send to the $content variable of the \email\html\default template
               ->template('default')
               ->emailFormat('html');
    }
    public function toProgramGroup(){
        
    }
    public function sendToMany($to,$users = null){
        if(null != $users){
            foreach ($users as $user) {
                
                $this->to($user->email)
               ->subject($to['subject'])
                ->viewVars(array('content'=>  $to['message']))
               ->template('default')
                ->emailFormat('html');
            }
        }
    }
    public function loginData($data)
    {
        if($data != null){
            foreach($data as $k=>$v){
                Log::write('info', $k.' '.$v);
                $this->to($k)
                        ->subject("Login information")
                        ->viewVars(array('content'=>$v))
                        ->emailFormat('html')
                        ->template('default');
            }
        }
    }
}
