<?php
namespace EShare\Form;

use Cake\Form\Form;
use Cake\Form\Schema;
use Cake\Log\Log;
use Cake\Validation\Validator;
use Cake\Mailer\MailerAwareTrait;

use Cake\Utility\Text;

/**
 * Compose Form.
 */
class ComposeForm extends Form
{
    use MailerAwareTrait;
    /**
     * Builds the schema for the modelless form
     *
     * @param Schema $schema From schema
     * @return $this
     */
    private $response = false;
    protected function _buildSchema(Schema $schema)
    {

        return $schema->addField('emailFrom','string')
            ->addField('to','string')
            ->addField('toEmail','string')
            ->addField('subject','string')
            ->addField('template','string')
            ->addField('message',['type'=>'text'])
            ;
    }

    /**
     * Form validation builder
     *
     * @param Validator $validator to use against the form
     * @return Validator
     */
    protected function _buildValidator(Validator $validator)
    {
        return $validator->add('emailFrom','required',['rule'=>'email','message'=>'please provide valid email'])
            ->allowEmpty(['toEmail','templates','to','signature'])
            ->notEmpty([
                'subject'=>['message'=>'subject cannot be left empty','when'=>true],
                'message'=>['message'=>'message cannot be left empty','when'=>true]
            ])->isArray('to',['message'=>'please select email group']);
    }

    /**
     * Defines what to execute once the From is being processed
     *
     * @param array $data Form data.
     * @return bool
     */
    protected function _execute(array $data)
    {

        return $this->dispatchMail($data) != false;
    }

    /**
     * Send email to receiver
     * @param $data
     * @return boolean true if email is sent
     */
    public function  dispatchMail($data){
        $mail_group = $data['to'];



        //if email is a group mail
        if (is_array($mail_group) && !empty($mail_group)) {
            if (count($mail_group) > 1) {
                for ($i = 0; $i < count($mail_group); $i++) {
                    $to = array_keys($mail_group[$i])[0];//get the receiver of the mail
                    $to_details = explode('/',array_values($mail_group[$i])[0]);//get the name of the receiver
                    $message = Text::insert($data['message'],['firstname'=>explode(" ",$to_details[0])[0],'surname'=>explode(" ",$to_details[0])[1],'name'=>$to_details[0],'designation'=>$to_details[1],'church'=>$to_details[2]]);

                    $mail_result[] = $this->getMailer('EShare.Dispatcher')->send('push',[$data,$to,$message,$to_details[0]]);
                    //Log::write('info',$this->Email->smtpError);
                }
                if(count($mail_result) == count($mail_group)){ // if the no of success = no of people that should have received
                    $this->response = true;
                }
            }
        }
        elseif(!empty($data['toEmail'])) {
            //if single email is sent the one user. or additional email that\'s not included in the mail list can be added here
            // SINGLE USER EMAILS ARE NOT REPLACED BECAUSE THE APP OBVIOUS DOESNT HAVE THEIR DETAILS
            // SO THERE ARE FILLED BY USER
            $this->response = is_array($this->getMailer('EShare.Dispatcher')->send('push',[$data,$data['toEmail'],$data['message']])) ?true : false;
        }
        return $this->response;
    }
}
