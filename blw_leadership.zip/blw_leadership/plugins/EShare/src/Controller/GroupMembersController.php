<?php
namespace Eshare\Controller;



use Cake\Datasource\ConnectionManager;
use Cake\Log\Log;

/**
 * GroupMembers Controller
 *
 * @property \Eshare\Model\Table\GroupMembersTable $GroupMembers
 * @property bool|object Upload
 */
class GroupMembersController extends AppController
{


    public function beforeFilter(\Cake\Event\Event $event) {
        $this->viewBuilder()->layout('EShare.index');
        return parent::beforeFilter($event);
    }

    /**
     * Index method
     *
     * @return \Cake\Network\Response|null
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['EmailGroup']
        ];
        $groupMembers = $this->paginate($this->GroupMembers);

        $this->set(compact('groupMembers'));
        $this->set('_serialize', ['groupMembers']);
    }

    /**
     * View method
     *
     * @param string|null $id Group Member id.
     * @return \Cake\Network\Response|null
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $groupMember = $this->GroupMembers->get($id, [
            'contain' => ['EmailGroup']
        ]);

        $this->set('groupMember', $groupMember);
        $this->set('_serialize', ['groupMember']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $groupMember = $this->GroupMembers->newEntity();
        $duplicates = [];
        if ($this->request->is('post')) {
            $groupMember = $this->GroupMembers->patchEntity($groupMember, $this->request->data);

            if($groupMember->email_group_id != 0){
                if($this->request->data['memberlist']['size'] > 0){ // if there is a file to be uploaded
                    $data = $this->Upload->csvUpload($this->request->data['memberlist']);

                   $groupMembers = ConnectionManager::get('default');
                   $data_row_test = $data[0][0];
                   if($data_row_test != "Firstname"){
                       $this->Flash->error(__('Invalid Csv file')); // on invalid csv don\'t save data
                   }
                   //on valid csv insert into db
                   for($i = 1; $i < count($data); $i++){
                       $count = $this->emailAlreadyExist($data[$i][2],$groupMember->email_group_id);

                       if(count($data[$i]) > 1 && $count == 0) {
                           $groupMembers->insert('group_members',[
                               'first_name'=>$data[$i][0],
                               'last_name'=>$data[$i][1],
                               'email'=>$data[$i][2],
                               'designation'=>$data[$i][3],
                               'church'=>$data[$i][4],
                               'email_group_id'=>$groupMember->email_group_id
                           ]);

                       }else{
                           $duplicates[] = $data[$i][0];
                       }
                   }
                   $errors = count($duplicates) > 1 ? count($duplicates).' Duplicate emails removed.': '';
                   $this->Flash->success(__('The group members has been saved. '.$errors));
                   return $this->redirect(['controller'=>'EmailGroup','action' => 'index']);

                }
                elseif(!empty($this->request->data['first_name']) && !empty($this->request->data['last_name']) && !empty($this->request->data['email'])){
                    $count = $this->emailAlreadyExist($this->request->data['email'],$groupMember->email_group_id);
                    if($count > 0){
                        $this->Flash->error(__('The group member could not be saved. Please, try again.'));
                        return $this->redirect(['action'=>'add']);
                    }
                    if ($this->GroupMembers->save($groupMember)) {
                        $this->Flash->success(__('The group member has been saved.'));
                        return $this->redirect(['controller'=>'EmailGroup','action' => 'index']);
                    } else {
                        $this->Flash->error(__('The group member could not be saved. Please, try again.'));
                    }
                }elseif(empty($this->request->data['first_name']) || empty($this->request->data['last_name']) || empty($this->request->data['email'])){
                    $this->Flash->error(__('Empty Fields Found. Please, try again.'));
                }


            }else {
                $this->Flash->error(__('Please select a group and try again.'));
            }
        }
        $emailGroups = $this->GroupMembers->EmailGroup->find('list', ['limit' => 200]);
        $this->set(compact('groupMember', 'emailGroups'));
        $this->set('_serialize', ['groupMember']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Group Member id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $groupMember = $this->GroupMembers->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $groupMember = $this->GroupMembers->patchEntity($groupMember, $this->request->data);
            if ($this->GroupMembers->save($groupMember)) {
                $this->Flash->success(__('The group member has been saved.'));

                return $this->redirect(['controller'=>'emailGroup','action' => 'index']);
            } else {
                $this->Flash->error(__('The group member could not be saved. Please, try again.'));
            }
        }
        $emailGroups = $this->GroupMembers->EmailGroup->find('list', ['limit' => 200]);
        $this->set(compact('groupMember', 'emailGroups'));
        $this->set('_serialize', ['groupMember']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Group Member id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $groupMember = $this->GroupMembers->get($id);
        if ($this->GroupMembers->delete($groupMember)) {
            $this->Flash->success(__('The group member has been deleted.'));
        } else {
            $this->Flash->error(__('The group member could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }

    /**
     * Confirm if email exist using the user find behavior
     * @param $email
     * @param $email_group
     * @return int
     */
    private function emailAlreadyExist($email,$email_group){
        return $this->GroupMembers->find('userEmail',['email'=>$email,'group_id'=>$email_group])->count();
    }
    public function export(){

        $data = [['','','','','']];
        $_header = ['Firstname','Lastname','email','designation','church'];
        $_serialize = 'data';
        $this->viewBuilder()->className('CsvView.Csv');
        $this->set(compact('_header','_serialize','data'));

    }
}
