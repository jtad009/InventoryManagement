<?php
include_once '../config/paths.php';
    // Allowed extentions.
    $allowedExts = array("txt", "pdf", "doc","png","jpg","jpeg");

    // Get filename.
    $temp = explode(".", $_FILES["file"]["name"]);

    // Get extension.
    $extension = end($temp);
   
    // Validate uploaded files.
    // Do not use $_FILES["file"]["type"] as it can be easily forged.
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime = finfo_file($finfo, $_FILES["file"]["tmp_name"]);
//echo $mime.'<br/>';
//echo $finfo;
    if ((($mime == "text/plain")
    || ($mime == "application/msword")
    || ($mime == "application/x-pdf")
    || ($mime == "application/pdf") 
    || ($mime == "image/png")
    || ($mime == "image/jpg")
    || ($mime == "image/jpeg"))
    && in_array($extension, $allowedExts)) {
       // echo "hi";
        // Generate new random name.
        $name = sha1(microtime()) . "." . $extension;

        // Save file in the uploads folder.
        if(move_uploaded_file($_FILES["file"]["tmp_name"],  'img/uploads/'. $name)){

            // Generate response.
            $response = new StdClass;
            $response->link =  'http://localhost/blw_leadership/webroot/img/uploads/'. $name;
            echo stripslashes(json_encode($response));
        }
    }
   
?>