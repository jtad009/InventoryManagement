<?php
namespace Eshare\Test\TestCase\Model\Table;

use Cake\ORM\TableRegistry;
use Cake\TestSuite\TestCase;
use Eshare\Model\Table\EmailtemplatesTable;

/**
 * Eshare\Model\Table\EmailtemplatesTable Test Case
 */
class EmailtemplatesTableTest extends TestCase
{

    /**
     * Test subject
     *
     * @var \Eshare\Model\Table\EmailtemplatesTable
     */
    public $Emailtemplates;

    /**
     * Fixtures
     *
     * @var array
     */
    public $fixtures = [
        'plugin.eshare.emailtemplates'
    ];

    /**
     * setUp method
     *
     * @return void
     */
    public function setUp()
    {
        parent::setUp();
        $config = TableRegistry::exists('Emailtemplates') ? [] : ['className' => 'Eshare\Model\Table\EmailtemplatesTable'];
        $this->Emailtemplates = TableRegistry::get('Emailtemplates', $config);
    }

    /**
     * tearDown method
     *
     * @return void
     */
    public function tearDown()
    {
        unset($this->Emailtemplates);

        parent::tearDown();
    }

    /**
     * Test initialize method
     *
     * @return void
     */
    public function testInitialize()
    {
        $this->markTestIncomplete('Not implemented yet.');
    }

    /**
     * Test validationDefault method
     *
     * @return void
     */
    public function testValidationDefault()
    {
        $this->markTestIncomplete('Not implemented yet.');
    }
}
