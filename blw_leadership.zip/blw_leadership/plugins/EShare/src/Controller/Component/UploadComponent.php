<?php
namespace EShare\Controller\Component;

use Cake\Controller\Component;
use Cake\Controller\ComponentRegistry;

use Cake\Filesystem\File;
use Cake\Log\Log;
use Cake\Network\Exception\InternalErrorException;
use Cake\Utility\Text;

/**
 * Upload component
 */
class UploadComponent extends Component
{

    /**
     * Default configuration.
     *
     * @var array
     *
     */
    protected $_defaultConfig = [];
    private $file = null;

    /**
     * Upload file to be used as attachment in email
     * @param $data
     * @return null|string file saved path of uploaded file
     */
    public function uploadAttachment($data){
        $filename = null;
        $message = null;

        if (!empty($data['name'])) {
            $filename= $data['name'];
            $file_tmp_name = $data['tmp_name'];
            $dir = WWW_ROOT . 'uploads' . DS . 'files';
            $allowed = array('png','doc','docx','pdf','jpg','jpeg','xlsx');
            if (!in_array(substr(strrchr($filename, '.'), 1), $allowed)) {
                throw new InternalErrorException("Error Processing Request", 1);
            } else if (is_uploaded_file($file_tmp_name)) {
                $filename = Text::Uuid().'-'.$filename;
                move_uploaded_file($file_tmp_name, $dir . DS . $filename);

            }

            $this->file = $dir.DS.$filename;


        }
        return $this->file;
    }
    /**
     * Get csv file and upload
     * @param $data data to parse
     * @return null|array array of csv lines on success or Null
     * @throws InternalErrorException
     */
    public function csvUpload($data){
        $filename = null;
        $message = null;

        if (!empty($data['name'])) {
            $filename= $data['name'];
            $file_tmp_name = $data['tmp_name'];
            $dir = WWW_ROOT . 'uploads' . DS . 'files';
            $allowed = array('csv');
            if (!in_array(substr(strrchr($filename, '.'), 1), $allowed)) {
                throw new InternalErrorException("Error Processing Request", 1);
            } else if (is_uploaded_file($file_tmp_name)) {
                $filename = Text::Uuid().'-'.$filename;
                move_uploaded_file($file_tmp_name, $dir . DS . $filename);

            }

            $this->file = $dir.DS.$filename;


        }
        return $this->parseFile();
    }

    /**
     * @return false|null|string
     */
    private function parseFile(){
        $contents = array();
        $file_handle = fopen($this->file,'r');
        while(!feof($file_handle)){
            $contents[] = fgetcsv($file_handle);
        }
        fclose($file_handle);
        //unlink($this->file);
        return  $contents;

    }
    public function emailMembersStrut(){


    }
}
