<?php
namespace App\Controller\Component;
use Cake\Controller\Component;
use Cake\Controller\ComponentRegistry;
use Cake\Network\Exception\InternalErrorException;
use Cake\Utility\Text;
use Cake\ORM\TableRegistry;
class UploadComponent extends Component {

    public $max_files = 3;
/**
 * Upload Video or Mp3 Or Photo to server
 * @todo Imporve to work with jquery or angular js and also check file type
 * @param file $data path to file
 * @return string
 * @throws InternalErrorException
 */
    public function send($data) {
        $filename = null;
        $message = null;
        $images_count = 0;
        if (!empty($data['name'])) {
            
           
               
                $filename= $data['name'];
                $file_tmp_name = $data['tmp_name'];
                $dir = WWW_ROOT . 'img' . DS . 'uploads';
                $allowed = array('png', 'jpg', 'jpeg','mp3','mp4','3gp');
                if (!in_array(substr(strrchr($filename, '.'), 1), $allowed)) {
                    throw new InternalErrorException("Error Processing Request", 1);
                } else if (is_uploaded_file($file_tmp_name)) {
                    $filename = Text::Uuid().'-'.$filename;
                    move_uploaded_file($file_tmp_name, $dir . DS . $filename);
                    
                }
            
            
        }
       return $filename;
    }
    

}
?>

