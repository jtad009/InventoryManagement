<?php
namespace Eshare\Test\TestCase\Controller;

use Cake\TestSuite\IntegrationTestCase;
use Eshare\Controller\EmailtemplatesController;

/**
 * Eshare\Controller\EmailtemplatesController Test Case
 */
class EmailtemplatesControllerTest extends IntegrationTestCase
{

    /**
     * Test initial setup
     *
     * @return void
     */
    public function testInitialization()
    {
        $this->markTestIncomplete('Not implemented yet.');
    }
}
