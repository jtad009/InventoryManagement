<?php
namespace Eshare\Controller;


use Cake\Datasource\ConnectionManager;
use Cake\Event\Event;


use Cake\Log\Log;
use Cake\Mailer\MailerAwareTrait;
use Cake\ORM\TableRegistry;

use EShare\Form\ComposeForm;



/**
 * Users Controller
 *
 * @property \Eshare\Model\Table\UsersTable $Users
 */
class UsersController extends AppController
{
    use MailerAwareTrait;

    /**
     * Index method
     *
     * @param Event $event
     * @return \Cake\Network\Response|null
     */
    public function beforeFilter(Event $event) {
        $this->viewBuilder()->layout('EShare.index');
        $this->Auth->allow('add');
        return parent::beforeFilter($event);
    }

    public function index()
    {
        $user = $this->Users->find('all')->where(['app'=>'email']);
        $users = $this->paginate($user);

        $this->set(compact('users'));
        $this->set('_serialize', ['users']);
    }

    /**
     * View method
     *
     * @param string|null $id User id.
     * @return \Cake\Network\Response|null
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $user = $this->Users->get($id, [
            'contain' => ['Emailtemplates', 'EmailGroup', 'EmailHistories']
        ]);

        $this->set('user', $user);
        $this->set('_serialize', ['user']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $user = $this->Users->newEntity();
        if ($this->request->is('post')) {
            $user = $this->Users->patchEntity($user, $this->request->data);
            $user->app = 'email';
            $user->password = md5($this->request->data['password']);
            if ($this->Users->save($user)) {
                $this->Flash->success(__('The user has been saved.'));

                return $this->redirect(['action' => 'login']);
            } else {
                $this->Flash->error(__('The user could not be saved. Please, try again.'));
            }
        }
        $this->set(compact('user'));
        $this->set('_serialize', ['user']);
    }

    /**
     * Edit method
     *
     * @param string|null $id User id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $user = $this->Users->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $user = $this->Users->patchEntity($user, $this->request->data);
            $user->password = md5($this->request->data['password']);
            if ($this->Users->save($user)) {
                $this->Flash->success(__('The user has been updated.'));


            } else {
                $this->Flash->error(__('The user could not be saved. Please, try again.'));
            }
        }
        $this->set(compact('user'));
        $this->set('_serialize', ['user']);
    }

    /**
     * Delete method
     *
     * @param string|null $id User id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $user = $this->Users->get($id);
        if ($this->Users->delete($user)) {
            $this->Flash->success(__('The user has been deleted.'));
        } else {
            $this->Flash->error(__('The user could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }

    public function sent(){
        $history = $this->Users->EmailHistories->find('all',['user_id'=>$this->Auth->user('id')])->order(['created' => 'ASC']);;

        $this->set('data',$history);
    }
    public function readMail($id = null){
        $history = null;
        if(null != $id){
            $history = $this->Users->EmailHistories->get($id);;
        }else{
            $this->redirect(['action' => 'sent']);
        }
        $this->set('mail',$history);
    }
    public function draft(){

    }

    /**
     *Send Emails out of system
     */
    public function compose(){
        $compose = new ComposeForm();

        if($this->request->is('post')){
            $memberTable = TableRegistry::get('group_members');
            $table = $memberTable->find('all')->where(['email_group_id'=>$this->request->data['to']]);
            $members = [];

            /*$members array will be of format
             * [0=>['email'=>'name'],1=>['email'=>'name'], ]
             */
            foreach ($table as $value) {
                $members[][$value['email']] =$value['first_name'].' '.$value['last_name'].'/'.$value['designation'].'/'.$value['church'];
            }

            $this->request->data['attachment'] = $this->Upload->uploadAttachment($this->request->data['attachment']);

            $this->request->data['to'] = $members;
            $this->request->data['user'] = $this->Auth->user('id');
            $this->request->data['replyTo'] = $this->getConfiguration()['replyTo'];
            $this->request->data['signature']= $this->getConfiguration()['signature'];
            $this->request->data['app_title'] = $this->getConfiguration()['app_title'];
            if($compose->execute($this->request->data)){
                $this->Flash->success('Message Sent');
            }else{
                $this->Flash->error('error sending email');
            }
        }

        $emailtemplate = $this->Users->Emailtemplates->find('all', [
            'contain' => []
        ])->where(['user_id'=>$this->Auth->user()['id']]);
Log::write('info',$this->Auth->user()['id']);
        $email_group = $this->Users->EmailGroup->find('list')->where(['user_id'=>$this->Auth->user()['id']]);

        $this->set('compose',$compose);
        $this->set('templates',$emailtemplate);
        $this->set('email_groups',$email_group);


        $this->set('setting',$this->getConfiguration());
        //test

        /*
         * next is to goto compose.ctp
         * and check for the variables passed and apply settings
         */
    }

    public function login() {

        //LETS find out if what we did works by seeing whats currently in the auth
        if ($this->request->is("post")) { // if the request gotten is a post request
            $user = $this->Auth->identify(); // identify the user

            if ($user['app'] == 'email') {
                $this->Auth->setUser($user);


                $this->set('loggedIn', $this->Auth->user());
                return $this->redirect(['controller'=>'users','action'=>'compose']);
            }
            //User could not be identified
            $this->Flash->error("Your username or password is incorrect");
        }
    }

    public function logout() {
        $this->Flash->success("You are now logged out");
        return $this->redirect($this->Auth->logout());
    }

    public function setting()
    {

        if($this->request->is('post')){
            $data = $this->request->data;

            //setting table
            $setting = ConnectionManager::get('default');
        if($data['id'] !="0"){
            $statement = $setting->update('settings',[
                'reply_email'=>$data['replyTo'],
                'signature'=>$data['signature'],
                'APP_TITLE'=>$data['app_title']
            ],[
                'user_id'=>$this->Auth->user('id'),//id of the current logged in user
             ]);
            $lastInsert = $statement->lastInsertId();
            if($lastInsert != "0")
                $this->Flash->success(__("Update Saved"));
        }else{
            $statement = $setting->insert('settings',[
                'user_id'=>$this->Auth->user('id'),//id of the current logged in user
                'reply_email'=>$data['replyTo'],
                'signature'=>$data['signature'],
                'APP_TITLE'=>$data['app_title']
            ]);
            $lastInsert = $statement->lastInsertId();
            if($lastInsert != "0"){
                $this->Flash->success("Data was inserted into the database");
            }
        }


            //saved data into setting table
            //currently looking for documentation on insert method to know if it returns a boolean of not
        }

        $this->set('config',$this->getConfiguration());
    }

    /**
     * Get app configurations
     * @return array
     */
    private function getConfiguration(){
        $config = [];
        $settings = $this->Users->Settings->find()->where(['user_id'=>$this->Auth->user('id')]);

        foreach($settings as $setting){
            $config['id'] = $setting['user_id'];
            $config['replyTo'] = $setting['reply_email'];
            $config['signature'] = $setting['signature'];
            $config['app_title'] = $setting['APP_TITLE'];

        }
        return $config;
    }
}
