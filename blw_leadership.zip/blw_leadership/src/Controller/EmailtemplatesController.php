<?php
namespace App\Controller;

use App\Controller\AppController;
use Cake\Mailer\MailerAwareTrait;
use Cake\Log\Log;
/**
 * Emailtemplates Controller
 *
 * @property \App\Model\Table\EmailtemplatesTable $Emailtemplates
 */
class EmailtemplatesController extends AppController
{
    use MailerAwareTrait;
    /**
     * Index method
     *
     * @return \Cake\Network\Response|null
     */
    public function implementedEvents() {
        return array(
            'Model.Emailtemplates.sendWelcome'=>'sendToUser',
            'Model.Users.sendLoginDetails'=>'sendLoginData'
            );
    }

    public function index()
    {
        $emailtemplates = $this->paginate($this->Emailtemplates);

        $this->set(compact('emailtemplates'));
        $this->set('_serialize', ['emailtemplates']);
    }

    /**
     * View method
     *
     * @param string|null $id Emailtemplate id.
     * @return \Cake\Network\Response|null
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $emailtemplate = $this->Emailtemplates->get($id, [
            'contain' => []
        ]);

        $this->set('emailtemplate', $emailtemplate);
        $this->set('_serialize', ['emailtemplate']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $emailtemplate = $this->Emailtemplates->newEntity();
        if ($this->request->is('post')) {
            $emailtemplate = $this->Emailtemplates->patchEntity($emailtemplate, $this->request->data);
            if ($this->Emailtemplates->save($emailtemplate)) {
                $this->Flash->success(__('The emailtemplate has been saved.'));

                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The emailtemplate could not be saved. Please, try again.'));
            }
        }
        $this->set(compact('emailtemplate'));
        $this->set('_serialize', ['emailtemplate']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Emailtemplate id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $emailtemplate = $this->Emailtemplates->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $emailtemplate = $this->Emailtemplates->patchEntity($emailtemplate, $this->request->data);
            if ($this->Emailtemplates->save($emailtemplate)) {
                $this->Flash->success(__('The emailtemplate has been saved.'));

                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The emailtemplate could not be saved. Please, try again.'));
            }
        }
        $this->set(compact('emailtemplate'));
        $this->set('_serialize', ['emailtemplate']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Emailtemplate id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $emailtemplate = $this->Emailtemplates->get($id);
        if ($this->Emailtemplates->delete($emailtemplate)) {
            $this->Flash->success(__('The emailtemplate has been deleted.'));
        } else {
            $this->Flash->error(__('The emailtemplate could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }
    public function compose(){
        //send email to users mail
       $emailtemplate = $this->Emailtemplates->find('all', [
            'contain' => []
        ]);
       if($this->request->is('post')){
          
           if(false != mb_stripos($this->request->data['message'],'welcome to leadership development center')
                   && false != mb_stripos($this->request->data['message'], 'pin')
                   && false != mb_stripos($this->request->data['message'], 'download'))
           {
                
               //generate and event to the usercontroller listener and request for the details a user with the passed in email address
               $event = new \Cake\Event\Event('Model.Emailtemplates.getUserDetails', $this, ['email'=>$this->request->data]);
               $this->eventManager()->dispatch($event);
           }else{
              if (!$this->getMailer('Emailsystem')->send('push', [$this->request->data])) {
                    CakeLog::write('debug', $this->Email->smtpError); // 
                    $this->Flash->Error('Message Not Sent to ' . $this->request->data['to']);
                    $this->redirect(['action' => 'compose']);
                } else {
                    $this->Flash->success('Message Sent to ' . $this->request->data['to']);
                    $this->redirect(['action' => 'compose']);
                }
            }
            
       } 
       $this->set('templates', $emailtemplate);
    }
    public function sendToAll(){
        if($this->request->is('post')){
            $users = \Cake\ORM\TableRegistry::get('Users');
            $user = $users->find()->select('email');
            if(!$this->getMailer('Emailsystem')->send('sendToMany',[$this->request->data,$user])){
             CakeLog::write('debug', $this->Email->smtpError);//  email error 
                 $this->Flash->error('Message Not Sent');
                 $this->redirect(['action'=>'compose']);
             }else{
                 $this->Flash->success('Message Sent');
                 $this->redirect(['action'=>'compose']);
             }
        }
    }
    public function programgroup(){
        if($this->request->is('post')){
            $program_id = $this->request->data['to'];// get the program for which email will be sent to its members
            $getuser = \Cake\ORM\TableRegistry::get('Programgroups');
            //search the program group to find members to send emails to 
            $groupUsers = $getuser->find()->andWhere(['program_id = '=>$program_id]); 
            
            foreach ($groupUsers as $user){
               
                $users = \Cake\ORM\TableRegistry::get('Users');
                $groupusersArray = $users->find()
                        ->select(['email'])
                        ->where(['id = '=>$user->user_id]); // find all the users that r in this particular group
                 
                $this->sendEmailToGroup($this->getEmail($groupusersArray),$this->request->data);
            }
            
          
            
        }
    }
    
        //custom functions
        private function getEmail($array){
            foreach($array as $user_email){
                    return  $user_email->email;
                }
        }
        //private function to sent email to program group without clustering the function above with loops
        private function sendEmailToGroup($users_email,$requestData){
             if(!$this->getMailer('Emailsystem')->send('toProgramGroup',[$users_email,$requestData])){
                 CakeLog::write('debug', $this->Email->smtpError);//  email error 
                 $this->Flash->error('Group Message Not Sent');
                 $this->redirect(['action'=>'compose']);
             }else{
                 $this->Flash->success('Group Message Sent');
                 $this->redirect(['action'=>'compose']);
             }
        }
        
        /*
         * Event listeners
         */
        public function sendToUser(\Cake\Event\Event $event, $entity)
        {
            Log::write('info', $event->data['user']);
            $msg = $event->data['email_data']['message'].'<br/> <strong>Pin: '.$event->data['user'].'</strong>';
            $event->data['email_data']['message'] = $msg;
           
            if(!$this->getMailer('Emailsystem')->send('push',[$event->data['email_data']])){
                 CakeLog::write('debug', $this->Email->smtpError);// 
                $this->Flash->Error('Message Not Sent to '.$event->data['email_data']['to']);
                $this->redirect(['action'=>'compose']);
            }else{
                $this->Flash->success('Message Sent to '.$event->data['email_data']['to']);
                $this->redirect(['action'=>'compose']);
            }
        }
        
        public function sendLoginData(\Cake\Event\Event $event, $entity)
        {
           
            if(!$this->getMailer('Emailsystem')->send('loginData',[$event->data['emails']])){
               CakeLog::write('debug', $this->Email->smtpError);// 
             }else{
                Log::write("info", "Mail sent");
            }
        
        }
    }

