<?php
namespace App\Model\Behavior;

use Cake\ORM\Behavior;
use Cake\ORM\Table;

/**
 * CatergoryUserFind behavior
 */
class CatergoryUserFindBehavior extends Behavior
{

    /**
     * Default configuration.
     *
     * @var array
     */
    protected $_defaultConfig = [];
    /**
     * Find Users for a particular category
     * Takes a category and returns users in that category
     * @param \Cake\ORM\Query $query
     * @param array $options
     */
    public function findForPrograms(\Cake\ORM\Query $query, array $options)
    {
        
        return $query->where('program_id',$options['program_id']); 
    }
}
