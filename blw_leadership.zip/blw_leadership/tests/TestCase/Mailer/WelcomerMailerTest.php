<?php
namespace App\Test\TestCase\Mailer;

use App\Mailer\WelcomerMailer;
use Cake\TestSuite\TestCase;

/**
 * App\Mailer\WelcomerMailer Test Case
 */
class WelcomerMailerTest extends TestCase
{

    /**
     * Test subject
     *
     * @var \App\Mailer\WelcomerMailer
     */
    public $Welcomer;

    /**
     * Test initial setup
     *
     * @return void
     */
    public function testInitialization()
    {
        $this->markTestIncomplete('Not implemented yet.');
    }
}
