<?php
namespace Eshare\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * EmailGroup Model
 *
 * @property \Cake\ORM\Association\BelongsTo $Users
 * @property \Cake\ORM\Association\HasMany $GroupMembers
 *
 * @method \Eshare\Model\Entity\EmailGroup get($primaryKey, $options = [])
 * @method \Eshare\Model\Entity\EmailGroup newEntity($data = null, array $options = [])
 * @method \Eshare\Model\Entity\EmailGroup[] newEntities(array $data, array $options = [])
 * @method \Eshare\Model\Entity\EmailGroup|bool save(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \Eshare\Model\Entity\EmailGroup patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method \Eshare\Model\Entity\EmailGroup[] patchEntities($entities, array $data, array $options = [])
 * @method \Eshare\Model\Entity\EmailGroup findOrCreate($search, callable $callback = null)
 */
class EmailGroupTable extends Table
{

    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config)
    {
        parent::initialize($config);

        $this->table('email_group');
        $this->displayField('title');
        $this->primaryKey('id');

        $this->belongsTo('Users', [
            'foreignKey' => 'user_id',
            'joinType' => 'INNER',
            'className' => 'Eshare.Users'
        ]);
        $this->hasMany('GroupMembers', [
            'foreignKey' => 'email_group_id',
            'className' => 'Eshare.GroupMembers'
        ]);
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator)
    {
        $validator
            ->integer('id')
            ->allowEmpty('id', 'create');

        $validator
            ->requirePresence('title', 'create')
            ->notEmpty('title');

     

//        $validator
//            ->integer('group_member_count')
//            ->requirePresence('group_member_count', 'create')
//            ->notEmpty('group_member_count');

        return $validator;
    }

    /**
     * Returns a rules checker object that will be used for validating
     * application integrity.
     *
     * @param \Cake\ORM\RulesChecker $rules The rules object to be modified.
     * @return \Cake\ORM\RulesChecker
     */
    public function buildRules(RulesChecker $rules)
    {
        $rules->add($rules->existsIn(['user_id'], 'Users'));

        return $rules;
    }
}
