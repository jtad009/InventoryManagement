<?php

namespace App\Controller;

use App\Controller\AppController;
use Cake\Log\Log;

/**
 * Articles Controller
 *
 * @property \App\Model\Table\ArticlesTable $Articles
 */
class ArticlesController extends AppController {

    /**
     * Index method
     *
     * @return \Cake\Network\Response|null
     */
    public function index() {
        
        $this->paginate = [
            'contain' => ['Programs']
        ];
        $articles = $this->paginate($this->Articles);

        $this->set(compact('articles'));
        $this->set('_serialize', ['articles']);
    }

    /**
     * View method
     *
     * @param string|null $id Article id.
     * @return \Cake\Network\Response|null
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null) {
        $article = $this->Articles->get($id, [
            'contain' => ['Programs', 'Comments']
        ]);

        $this->set('article', $article);
        $this->set('_serialize', ['article']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add() {
        $article = $this->Articles->newEntity();

        if ($this->request->is('post')) {
            // var_dump($this->request->data);
           
            $article = $this->Articles->patchEntity($article, $this->request->data);

            // next line is for upload to the upload component i wrote shud i wanna use it again
            $link = $this->Upload->send($this->request->data['attachment_link']);
            $article->attachment_link = $link;

            if (!empty($this->request->data['video_link']['name'])) {
                //var_dump($this->request->data['video_link']['name']);
                $video = $this->Upload->send($this->request->data['video_link']);
                $article->video_link = $video;
            } else {
                $article->video_link = "";
            }

            if ($this->Articles->save($article)) {
                $this->notifyUsers($article->published,$article); // tell users that a new post has been made only if the post is published
                $this->Flash->success(__('The article has been saved.'));

                //return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The article could not be saved. Please, try again.'));
            }
        }
        $programs = $this->Articles->Programs->find()->combine('id', 'program');
        $this->set(compact('article', 'programs'));
        $this->set('_serialize', ['article']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Article id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null) {
        $article = $this->Articles->get($id, [
            'contain' => ['Programs']
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            //if user didnt try to upload a new image then dont edit the current image for article.
            // this is done by getting the current one from the db n reinserting .
            //Limitation caused by not being able to dynamically fill file input with data
            
            $uploadError = array(1,2,3,4,5,6,7,8); //errorcode gotten from php.net
            $link = !in_array($this->request->data['attachment_link']['error'], $uploadError) 
                    ? $this->Upload->send($this->request->data['attachment_link']) : $article->attachment_link;
            $article = $this->Articles->patchEntity($article, $this->request->data);
            //$article->article_content = $this->request->data['article_content'];
            
            
            $article->attachment_link = $link;

            if (!empty($this->request->data['video_link']['name'])) {
                //var_dump($this->request->data['video_link']['name']);
                $video = $this->Upload->send($this->request->data['video_link']);
                $article->video_link = $video;
            } else {
                $article->video_link = "";
            }
            if ($this->Articles->save($article)) {
                $this->notifyUsers($article->published,$article); // tell users that a new post has been made only if the post is published
                $this->Flash->success(__('The article has been saved.'));

                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The article could not be saved. Please, try again.'));
            }
        }
        $programs = $this->Articles->Programs->find()->combine('id', 'program');
        $this->set(compact('article', 'programs'));
        $this->set('_serialize', ['article']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Article id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null) {
        $this->request->allowMethod(['post', 'delete']);
        $article = $this->Articles->get($id);
        if ($this->Articles->delete($article)) {
            $this->Flash->success(__('The article has been deleted.'));
        } else {
            $this->Flash->error(__('The article could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }

    public function approveComment($id = null) {
        $commentTable = \Cake\ORM\TableRegistry::get('comments');
        $comments = $commentTable->get($id);
        $comments->approved = "TRUE";
        if ($commentTable->save($comments)) {
            return $this->redirect(['action' => 'view', $comments->article_id]);
        }
    }

    public function disapproveComment($id = null) {
        $commentTable = \Cake\ORM\TableRegistry::get('comments');
        $comments = $commentTable->get($id);
        $comments->approved = "FALSE";
        if ($commentTable->save($comments)) {
            return $this->redirect(['action' => 'view', $comments->article_id]);
        }
    }

    public function upload() {
        if ($this->request->is('post')) {
            $link = $this->Upload->send($this->request->data['file']);
        }
        return "{ link: $link }";
    }

    public function export() {
        $articles = $this->Articles->find('all')->contain('Programs')->where(['program_id' => 3])
        ;
        $this->set('users', $articles);
    }

    private function notifyUsers($isPublished,  \App\Model\Entity\Article $article) {
        if ($isPublished == "TRUE") { // if is published then send event to user controller to push message
            $event = new \Cake\Event\Event('Model.Articles.created', $this, ['article' => $article]);
            $this->eventManager()->dispatch($event);
        }
    }

}
